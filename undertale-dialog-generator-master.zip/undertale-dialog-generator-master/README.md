![Everyone wants to talk like Papyrus!!!](/src/static/images/example.png)

A web app for generating Undertale dialog boxes. 
NOW LIVE at http://thehotvoice.mccowan.space/!
Also, catch me on Twitter: https://twitter.com/IDTHV

NOTE: IDTHV is not under terribly active development right now.
I consider it reasonably feature-complete and my enthusiasm for working on it
has waned somewhat. Don't expect much in the way of substantial updates
for the time being.

Made using the extremely nice and cool [Elm](http://elm-lang.org) language.
I wholeheartedly endorse it as an introduction to functional programming
OR a radical reworking of front-end web development!

The backend uses [Flask](http://flask.pocoo.org),
which isn't quite as exciting but extremely simple and easy to use!
